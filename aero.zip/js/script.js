$(document).ready(function() {
    $("#mycarousel1").carousel({ interval: 1500});
    $("#mycarousel2").carousel({ interval: 1500});
    $("#mycarousel3").carousel({ interval: 1500});
    $("#mycarousel4").carousel({ interval: 1500});
    $("#mycarousel5").carousel({ interval: 1500});
    $("#mycarousel1").css({
        'background-size': 'cover',
        'background-color': '#0f0f0f',
        'background-position': 50% 50%,
    });
    $("#mycarousel2").css({
        'background-size': 'cover',
        'background-color': '#0f0f0f',
        'background-position': 50% 50%,
    });
    $("#mycarousel3").css({
        'background-size': 'cover',
        'background-color': '#0f0f0f',
        'background-position': 50% 50%,
    });
    $("#mycarousel4").css({
        'background-size': 'cover',
        'background-color': '#0f0f0f',
        'background-position': 50% 50%,
    });
    $("#mycarousel5").css({
        'background-size': 'cover',
        'background-color': '#0f0f0f',
        'background-position': 50% 50%,
    });
    $("#carouselButton").click(function() {
        if ($('#carouselButton').children('span').hasClass('fa-pause')) {
            $("#mycarousel1").carousel('pause');
            $('#carouselButton').children('span').removeClass('fa-pause');
            $('#carouselButton').children('span').addClass('fa-play');
            }
        else if ($('#carouselButton').children('span').hasClass('fa-play')) {
            $("#mycarousel1").carousel('cycle');
            $('#carouselButton').children('span').removeClass('fa-play');
            $('#carouselButton').children('span').addClass('fa-pause');
            }
    });
    $("#carouselButton").click(function() {
        if ($('#carouselButton').children('span').hasClass('fa-pause')) {
            $("#mycarousel2").carousel('pause');
            $('#carouselButton').children('span').removeClass('fa-pause');
            $('#carouselButton').children('span').addClass('fa-play');
            }
        else if ($('#carouselButton').children('span').hasClass('fa-play')) {
            $("#mycarousel2").carousel('cycle');
            $('#carouselButton').children('span').removeClass('fa-play');
            $('#carouselButton').children('span').addClass('fa-pause');
            }
    });
});